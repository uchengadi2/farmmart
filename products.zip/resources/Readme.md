# ext-theme-neptune-ebf3c4e3-4ffd-4d06-9c1c-235bbf7ea0b1/resources

This folder contains static resources (typically an `"images"` folder as well).
