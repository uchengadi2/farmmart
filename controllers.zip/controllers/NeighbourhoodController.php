<?php

class NeighbourhoodController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listAllNeighbourhoods','addnewneighbourhood','modifyneighbourhood','deleteoneneighbourhood',
                                    'listallneighbourhoodinacluster','setintraneighbourhooddeliveryrates'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that will retrieve  all the neighbourhood in the market place
         */
        public function actionlistAllNeighbourhoods(){
             $model = new Neighbourhood;
            
             $hood = Neighbourhood::model()->findAll();
              header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "hood" => $hood,
                                   
                    
                            ));
            
        }
        
        
        /**
         * This is the function that adds new neighbourhood
         */
        public function actionaddnewneighbourhood(){
            
             $model=new Neighbourhood;

		
		$model->name = $_POST['name'];
                if(isset($_POST['description'])){
                   $model->description = $_POST['description']; 
                }
                
                $model->create_time = new CDbExpression('NOW()');
                $model->create_user_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'Successfully created new neighbourhood';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'New neighbourhood creation was unsuccessful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
        }
        
        
        /**
         * This is the function that modifies neighbourhood
         */
        public function actionmodifyneighbourhood(){
            
             $_id = $_POST['id'];
             $model=  Neighbourhood::model()->findByPk($_id);		
		$model->name = $_POST['name'];
                if(isset($_POST['description'])){
                   $model->description = $_POST['description']; 
                }
                
                $model->update_time = new CDbExpression('NOW()');
                $model->update_user_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'Successfully updated neighbourhood information';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'This new neighbourhood update was unsuccessful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
        }
        
        
        
        /**
	 * Deletes a particular model instance
	 * 
         **/
	public function actiondeleteoneneighbourhood()
	{
            
            $_id = $_REQUEST['id'];
            $model=  Neighbourhood::model()->findByPk($_id);
            
            //get the neighbourhood name
            $name = $_REQUEST['name'];
            
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$name' neighbourhood was successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
	}
        
        
        /**
         * This is the function that list all neighbourhoods in a cluster
         */
        public function actionlistallneighbourhoodinacluster(){
            
            $model = new ClusterNeighbourhoods;
            
            $cluster_id = $_REQUEST['cluster_id'];
            
           $hoods = $model->retrieveAllNieghbourhoodsInThisHood($cluster_id);
           
           $target = [];
           
           foreach($hoods as $hoodid){
              $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='id=:id';
              $criteria->params = array(':id'=>$hoodid);
              $thishood= Neighbourhood::model()->find($criteria);
              
              $target[] = $thishood;
           }
            header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "hood" => $target)
                           );
        }
        
        
        
         /**
         * This is the function that sets the intra neihbourhood delivery rate of a neighbourhood
         */
        public function actionsetintraneighbourhooddeliveryrates(){
            
                     
            $_id = $_REQUEST['id'];
            
            $model=  Neighbourhood::model()->findByPk($_id);
            $model->name = $_REQUEST['name'];
            //set the standard rate
            $model->intra_neighbourhood_base_rate = $_REQUEST['intra_neighbourhood_base_rate'];
            $model->intra_neighbourhood_maximum_base_weight = $_REQUEST['intra_neighbourhood_maximum_base_weight'];
            $model->intra_neighbourhood_per_additional_kg = $_REQUEST['intra_neighbourhood_per_additional_kg'];
            
              //set the priority rate
            $model->intra_neighbourhood_base_rate_priority = $_REQUEST['intra_neighbourhood_base_rate_priority'];
            $model->intra_neighbourhood_maximum_base_weight_priority = $_REQUEST['intra_neighbourhood_maximum_base_weight_priority'];
            $model->intra_neighbourhood_per_additional_kg_priority = $_REQUEST['intra_neighbourhood_per_additional_kg_priority'];
            
              //set the same day rate
            $model->intra_neighbourhood_base_rate_sameday = $_REQUEST['intra_neighbourhood_base_rate_sameday'];
            $model->intra_neighbourhood_maximum_base_weight_sameday = $_REQUEST['intra_neighbourhood_maximum_base_weight_sameday'];
            $model->intra_neighbourhood_per_additional_kg_sameday = $_REQUEST['intra_neighbourhood_per_additional_kg_sameday'];
            
            $model->update_time = new CDbExpression('NOW()');
            //$model->update_user_id = Yii::app()->user->id;
            if($model->save()){
                       // $data['success'] = 'true';
                        $msg = 'The intra neighbourhood delivery rate for this neighbourhood is successfully set or modified';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                }else {
                   // $data['success'] = 'false';
                    $msg = 'Attempt to set or modify the intra neighbourhood delivery rate for this neihbourhood failed';
                     header('Content-Type: application/json');
                     echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                }
        }
}
