<?php

class OrderController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view','placeorder','placeorderbymobile'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listAllOpenOrders','listAllMerchantOpenOrders','listAllOrders','retrievesomeitemsdetails',
                                    'listAllOpenOrders','listAllOpenOrdersWithConfirmedPayment','placecartorder','listCustomerAllOrders'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
	 * Displays a particular model.
	 * @param integer $id the ID of the model to be displayed
	 */
	public function actionView($id)
	{
		$this->render('view',array(
			'model'=>$this->loadModel($id),
		));
	}

	/**
         * This is the function that list all open orders
         */
        public function actionlistAllOpenOrders(){
            
             $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='status=:status';
              $criteria->params = array(':status'=>"open");
              $orders= Order::model()->findAll($criteria);
              
              header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "order" => $orders,
                                   
                    
                            ));
              
        }
        
        
        /**
         * This is the function that retrieves all merchant items in open oeders
         */
        public function actionlistAllMerchantOpenOrders(){
            $model = new User;
            $user_id = Yii::app()->user->id;
            
            $merchant_id = $model->getTheMerchantIdOfThisUser($user_id);
            
                        
            //retrieve all the open orders
                   
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='status=:status';
            $criteria->params = array(':status'=>"open");
            $orders= Order::model()->findAll($criteria);
            
            
            
             
           $target = [];
           foreach($orders as $order){
              if($this->isThisOrderWithMerchantProduct($order['id'],$merchant_id)){
                   $target[] = $order;
               }
              
          }
           
           
           
           
           
           header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    //"order" => $items,
                                    "order"=>$target,
                                   
                            ));
            
            
        }
        
        
        /**
         * This is the function that confirms if an order containes a merchant's product
         */
        public function isThisOrderWithMerchantProduct($order_id,$merchant_id){
            $model = new OrderItem;
            return $model->isThisOrderWithMerchantProduct($order_id,$merchant_id);
        }
        
        
        /**
         * this is the function that list all orders
         */
        public function actionlistAllOrders(){
             $order = Order::model()->findAll();
               header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "order" => $order,
                                   
                    
                            ));
        }
        
        
        /**
         * This is the function that retrieves some details about an order item
         */
        public function actionretrievesomeitemsdetails(){
            
            $product_id = $_REQUEST['product_id'];
            $order_id = $_REQUEST['order_id'];
            $pricing_id = $_REQUEST['pricing_id'];
            $promotion_id = $_REQUEST['promotion_id'];
                    
            
            //get the product details
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$product_id);
            $product= Product::model()->find($criteria);
            
            //get the order details
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$order_id);
            $order= Order::model()->find($criteria);
            
             //get the city of delivery details
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$order['delivery_city_id']);
            $city= City::model()->find($criteria);
            
            
             //get the stateof delivery details
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$city['state_id']);
            $state= State::model()->find($criteria);
            
            //get the unit pricing details
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$pricing_id);
            $pricing= Pricing::model()->find($criteria);
            
            //get the pricing details
              //get the unit measurement type details
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$pricing['measurement_type_id']);
            $unit= MeasurementType::model()->find($criteria);
            
               //get the product pricing promotion details
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$promotion_id);
            $promotion= Promotion::model()->find($criteria);
            
            
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "order" => $order,
                                   "product"=>$product,
                                    "unit"=>$unit,
                                    "pricing"=>$pricing,
                                    "promotion"=>$promotion,
                                    "city"=>$city,
                                    "state"=>$state
                    
                            ));
            
        }
        
        
        
        /**
         * This is the function that list all open orders with confirmed payment
         */
        public function actionlistAllOpenOrdersWithConfirmedPayment(){
            $model = new Payment;
             $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='status=:status';
              $criteria->params = array(':status'=>"open");
              $orders= Order::model()->findAll($criteria);
              
              $target = [];
              
              foreach($orders as $order){
                  if($model->isThePaymentOfThisOrderConfirmed($order['id'])){
                      $target[] = $order;
                  }
              }
              
              header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "order" => $target,
                                   
                    
                            ));
              
        }
        
        
        /**
         * This is the function that places an order fou anonynous buy now customer 
         */
        public function actionplaceorder(){
            $model = new Order;
            
                $delivery_cost = $_REQUEST['delivery_cost'];
                $total_cost_deposit = $_REQUEST['total_cost_deposit'];
                $model->status = "open";
                $model->delivery_address = $_REQUEST['delivery_address'];
                $model->delivery_city_id = $_REQUEST['delivery_city_id'];
                $model->receiver_mobile_number = $_REQUEST['receiver_mobile_number'];
                $model->address_landmark = $_REQUEST['address_landmark'];
                $model->nearest_bus_stop = $_REQUEST['nearest_bus_stop'];
                $model->person_in_care_of = $_REQUEST['person_in_care_of'];
                $model->delivery_preference = strtolower($_REQUEST['delivery_preference']);
                $model->other_relevent_information = $_REQUEST['other_relevent_information'];
                $model->date_ordered = new CDbExpression('NOW()');
                $model->ordered_by = $_REQUEST['logged_in_user_id'];
                $model->email = $_REQUEST['email'];
                $model->mobile_number = $_REQUEST['mobile_number'];
                $cart_id=0;
                
                $model->order_number = $model->generateThisOrderUniqueNumber($cart_id,$_REQUEST['warehouse_location_id'],$model->delivery_city_id);
                $error_counter = 0;
                
                
                
                   if($_REQUEST['is_a_prime_member']==1){
                       if($this->isThisUserAPrimeMember($_REQUEST['prime_member_number'])){
                           $model->is_a_prime_member = $_REQUEST['is_a_prime_member'];
                            $model->prime_member_number = $_REQUEST['prime_member_number'];
                            $total_price_of_items= $_REQUEST['prime_members_total_price_post_promotion_and_delivery'];
                            $is_a_prime_member=1;
                       }else{
                           $error_counter = $error_counter + 1;
                           $is_a_prime_member=0;
                           $total_price_of_items= $_REQUEST['total_price_post_promotion_and_delivery'];
                           $model->prime_member_number ="";
                       }
                       
                   }else{
                        $model->is_a_prime_member = 0;
                        $model->prime_member_number = " ";
                        $total_price_of_items= $_REQUEST['total_price_post_promotion_and_delivery'];
                        $is_a_prime_member=0;
                   }
                   
                 if($_REQUEST['payment_mode'] == "on_deposit_using_online"){
                       $total_cost_deposit = round($total_cost_deposit,2);
                       $total_price_of_items = round($total_price_of_items,2);
                       
                   }else if($_REQUEST['payment_mode'] == "on_deposit_using_bank_transfer"){
                       $total_cost_deposit = round($total_cost_deposit,2);
                       $total_price_of_items = round($total_price_of_items,2);
                   }else{
                       $total_cost_deposit=round($total_price_of_items,2);
                       $total_price_of_items=round($total_price_of_items,2);
                   }
                
                
                   
                   if($error_counter == 0){
                       if($model->save()){
                          $cost_per_unit = $this->getThePriceOfThisPricingId($_REQUEST['pricing_id']);
                          $unit = $this->getTheUnitOfThisPricing($_REQUEST['pricing_id']);
                          $prime_customer_discount_rate = $this->getThePrimeCustomerDiscountRate($_REQUEST['pricing_id']);
                    if($this->isOrderItemDetailsCorrectlyCreated($model->id,$_REQUEST['product_id'],$_REQUEST['quantity'],$_REQUEST['measurement_type_id'],$_REQUEST['promotion_id'],$_REQUEST['pricing_id'],$model->ordered_by,$cost_per_unit,$unit,$prime_customer_discount_rate)){
                        $invoice_number = $this->makePaymentAndGenerateTheInvoiceNumber($model->id,$model->order_number,$_REQUEST['payment_mode'],$delivery_cost,$total_cost_deposit,$total_price_of_items,$model->ordered_by,$cart_id,$_REQUEST['warehouse_location_id'],$model->delivery_city_id);
                             if($_REQUEST['payment_mode'] == "on_deposit_using_online"){
                                  header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                        "success" => mysqli_connect_errno() == 0,
                                        "invoice_number" => $invoice_number,
                                        "order_number"=>$model->order_number,
                                        "is_a_prime_member"=>$is_a_prime_member,
                                        "amount"=>round($total_cost_deposit,2),
                                        "email"=>$model->email,
                                        "membership_number"=>$model->prime_member_number
                                    ));
                                 
                             }else if($_REQUEST['payment_mode'] == "on_deposit_using_bank_transfer"){
                                 $msg = "Your order number is '$model->order_number' and the invoice number is '$invoice_number'. Please effect transfer using the order number attribute for easy verification";
                                 header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                        "success" => mysqli_connect_errno() == 0,
                                        "msg" =>$msg,
                                         "invoice_number" => $invoice_number,
                                        "order_number"=>$model->order_number,
                                        "is_a_prime_member"=>$is_a_prime_member
                                    ));
                                 
                             }else if($_REQUEST['payment_mode'] == "online"){
                                 header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                        "success" => mysqli_connect_errno() == 0,
                                        "invoice_number" => $invoice_number,
                                        "order_number"=>$model->order_number,
                                        "is_a_prime_member"=>$is_a_prime_member=0,
                                        "amount"=>round($total_price_of_items,2),
                                        "email"=>$model->email,
                                        "membership_number"=>$model->prime_member_number
                                    ));
                                 
                             }else if($_REQUEST['payment_mode'] == "on_delivery"){
                                 $msg = "Your order number is '$model->order_number' and the invoice number is '$invoice_number'. On delivery you will have to pay the total sum of '=N=$total_price_of_items' before taking ownership of the product ";
                                 header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                        "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg,
                                        
                                    ));
                                 
                             }else if($_REQUEST['payment_mode'] == "bank_transfer"){
                                 $msg = "Effect the bank transfer using this order number: '$model->order_number' in the transfer instruction. However, the invoice number of this transaction is '$invoice_number'";
                                  header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                        "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg,
                                         "invoice_number" => $invoice_number,
                                        "order_number"=>$model->order_number
                                        
                                    ));
                             }else if($_REQUEST['payment_mode'] == "on_credit"){
                                 $msg = "Validaion Error: Check your file fields for correctness";
                                 header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                        "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg,
                                         "invoice_number" => $invoice_number,
                                        "order_number"=>$model->order_number
                                        
                                    ));
                             }
                                
                   
                    }
                }else{
                    $msg = 'Attempt to place this order was not successful. Please try again or contact customer service';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                               );
                
                
                }
                       
                   }else{
                        $msg = 'Your Prime Membership number could not be verified. Kindly check the number and try again';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                               );
                       
                   }
            
            
                
          
            
            
        }
        
        
        /**
         * This is the function that returns the price per unit of a pricing
         */
        public function getThePriceOfThisPricingId($pricing_id){
            $model = new Pricing;
            return $model->getThePriceOfThisPricingId($pricing_id);
        }
        
        
        /**
         * This is the function that returns the  unit of a pricing
         */
        public function getTheUnitOfThisPricing($pricing_id){
            $model = new Pricing;
            return $model->getTheUnitOfThisPricing($pricing_id);
        }
        
        
        
         /**
         * This is the function that returns the  prime member discount rate of a pricing
         */
        public function getThePrimeCustomerDiscountRate($pricing_id){
            $model = new Pricing;
            return $model->getThePrimeCustomerDiscountRate($pricing_id);
        }
        
        
        /**
         * This is the function that adds an item to an order
         */
        public function isOrderItemDetailsCorrectlyCreated($order_id,$product_id,$quantity,$measurement_type_id,$promotion_id,$pricing_id,$ordered_by,$cost_per_unit,$unit,$prime_customer_discount_rate){
            $model = new OrderItem;
            return $model->isOrderItemDetailsCorrectlyCreated($order_id,$product_id,$quantity,$measurement_type_id,$promotion_id,$pricing_id,$ordered_by,$cost_per_unit,$unit,$prime_customer_discount_rate);
            
        }
        
        /**
         * This is the function that effects an order payment
         */
        public function makePaymentAndGenerateTheInvoiceNumber($order_id,$order_number,$payment_mode,$delivery_cost,$total_cost_deposit,$total_price_of_items,$ordered_by,$cart_id,$warehouse_location_id,$delivery_city_id){
            $model = new Payment;
            return $model->makePaymentAndGenerateTheInvoiceNumber($order_id,$order_number,$payment_mode,$delivery_cost,$total_cost_deposit,$total_price_of_items,$ordered_by,$cart_id,$warehouse_location_id,$delivery_city_id);
            
        }
        
        
        /**
         * This is the function that determines if a user is a prime member
         */
        public function isThisUserAPrimeMember($prime_member_number){
            $model = new Membership;
            return $model->isThisUserAPrimeMember($prime_member_number);
        }
        
        
        
         /**
         * This is the function that determines if a user id ssociates with prime membership
         */
        public function isThisUserIdAPrimeMember($user_id){
            $model = new Membership;
            return $model->isThisUserIdAPrimeMember($user_id);
        }
        
        
        /**
         * This is the function that retrieves the membership number of this prime user
         */
        public function getTheMembershipNumberOfThisUser($user_id){
            $model = new Membership;
            return $model->getTheMembershipNumberOfThisUser($user_id);
        }
        
        
        
        /**
         * This is the function that places an order from cart
         */
        public function actionplacecartorder(){
            
            $model = new Order;
            
            
                $delivery_cost = $_REQUEST['delivery_cost'];
                $total_cost_deposit = $_REQUEST['total_cost_deposit'];
                $model->status = "open";
                $model->delivery_address = $_REQUEST['delivery_address'];
                $model->delivery_city_id = $_REQUEST['delivery_city_id'];
                $model->receiver_mobile_number = $_REQUEST['receiver_mobile_number'];
                $model->address_landmark = $_REQUEST['address_landmark'];
                $model->nearest_bus_stop = $_REQUEST['nearest_bus_stop'];
                $model->person_in_care_of = $_REQUEST['person_in_care_of'];
                $model->delivery_preference = $_REQUEST['delivery_preference'];
                $model->other_relevent_information = $_REQUEST['other_relevent_information'];
                $model->date_ordered = new CDbExpression('NOW()');
                $model->ordered_by = $_REQUEST['logged_in_user_id'];
                          
                $cart_id = $_REQUEST['cart_id'];
                
                if($this->isThisCartOpen($cart_id)){
                    $model->order_number = $model->generateThisOrderUniqueNumber($cart_id,$warehouse_location_id=0,$model->delivery_city_id);
                $error_counter = 0;
                
                
                if($_REQUEST['is_a_prime_member']==1){
                       if($this->isThisUserIdAPrimeMember($model->ordered_by)){
                           $model->is_a_prime_member = $_REQUEST['is_a_prime_member'];
                            $model->prime_member_number = $this->getTheMembershipNumberOfThisUser($model->ordered_by);
                            $total_price_of_items= $_REQUEST['cart_items_total_price_post_promotion_and_delivery_for_prime'];
                            $is_a_prime_member=1;
                       }else{
                           $error_counter = $error_counter + 1;
                           $is_a_prime_member=0;
                           $total_price_of_items= $_REQUEST['cart_items_total_price_post_promotion_and_delivery'];
                           $model->prime_member_number ="";
                       }
                       
                   }else{
                        $model->is_a_prime_member = 0;
                        $model->prime_member_number = " ";
                        $total_price_of_items= $_REQUEST['cart_items_total_price_post_promotion_and_delivery'];
                        $is_a_prime_member=0;
                   }
                   
                 if($_REQUEST['payment_mode'] == "on_deposit_using_online"){
                       $total_cost_deposit = round($total_cost_deposit,2);
                       $total_price_of_items = round($total_price_of_items,2);
                       
                   }else if($_REQUEST['payment_mode'] == "on_deposit_using_bank_transfer"){
                       $total_cost_deposit = round($total_cost_deposit,2);
                       $total_price_of_items = round($total_price_of_items,2);
                   }else{
                       $total_cost_deposit=round($total_price_of_items,2);
                       $total_price_of_items=round($total_price_of_items,2);
                   }
                
                
                   
                   if($error_counter == 0){
                       $counter = 0;
                    if($model->save()){
                        //retrieve all the items in the cart
                        $items = $this->getAllTheItemsInThisCart($cart_id);
                        $invoice_number = $this->makePaymentAndGenerateTheInvoiceNumber($model->id,$model->order_number,$_REQUEST['payment_mode'],$delivery_cost,$total_cost_deposit,$total_price_of_items,$model->ordered_by,$cart_id,$_REQUEST['warehouse_location_id'],$model->delivery_city_id);
                        foreach($items as $item){
                            $product_id = $this->getTheProductIdOfThisItem($item);
                            $quantity = $this->getThisCartItemQuantity($item);
                            $product_measurement_type = $this->getTheMeasurementTypeOfThisCartItem($item);
                            $promotion_id = $this->getThePromotionIdOfThisCartItemId($item);
                            $pricing_id = $this->getThePricingIdOfThisCartItem($item);
                            $cost_per_unit = $this->getTheCostPerItemOfThisItem($item);
                            $unit = $this->getTheUnitOfThisItem($item);
                            $prime_customer_discount_rate = $this->getThePrimeCustomerDiscountRateOfThisItem($item);
                            //insert this into the order item table
                        if($this->isOrderItemDetailsCorrectlyCreated($model->id,$product_id,$quantity,$product_measurement_type,$promotion_id,$pricing_id,$model->ordered_by,$cost_per_unit,$unit,$prime_customer_discount_rate)){
                            continue;
                            
                          }else{
                            $counter = $counter + 1;
                        }
                        }
                        
                        if($counter == 0){
                            //close this cart
                            $this->closeThisCart($cart_id);
                            if($_REQUEST['payment_mode'] == "on_deposit_using_online"){
                                  header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                        "success" => mysqli_connect_errno() == 0,
                                        "invoice_number" => $invoice_number,
                                        "order_number"=>$model->order_number,
                                        "is_a_prime_member"=>$is_a_prime_member,
                                        "amount"=>round($total_cost_deposit,2),
                                        "email"=>$this->getTheEmailAddressOfThisUser($model->ordered_by),
                                        //"membership_number"=>$model->prime_member_number
                                    ));
                                 
                             }else if($_REQUEST['payment_mode'] == "on_deposit_using_bank_transfer"){
                                 $msg = "Your order number is '$model->order_number' and the invoice number is '$invoice_number'. Please effect transfer using the order number attribute for easy verification";
                                 header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                        "success" => mysqli_connect_errno() == 0,
                                        "msg" =>$msg,
                                         "invoice_number" => $invoice_number,
                                        "order_number"=>$model->order_number,
                                        "is_a_prime_member"=>$is_a_prime_member
                                    ));
                                 
                             }else if($_REQUEST['payment_mode'] == "online"){
                                 header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                        "success" => mysqli_connect_errno() == 0,
                                        "invoice_number" => $invoice_number,
                                        "order_number"=>$model->order_number,
                                        "is_a_prime_member"=>$is_a_prime_member=0,
                                        "amount"=>round($total_price_of_items,2),
                                        "email"=>$this->getTheEmailAddressOfThisUser($model->ordered_by),
                                        //"membership_number"=>$model->prime_member_number
                                    ));
                                 
                             }else if($_REQUEST['payment_mode'] == "on_delivery"){
                                 $msg = "Your order number is '$model->order_number' and the invoice number is '$invoice_number'. On delivery you will have to pay the total sum of '=N=$total_price_of_items' before taking ownership of the product ";
                                 header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                        "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg,
                                        
                                    ));
                                 
                             }else if($_REQUEST['payment_mode'] == "bank_transfer"){
                                 $msg = "Effect the bank transfer using this order number: '$model->order_number' in the transfer instruction. However, the invoice number of this transaction is '$invoice_number'";
                                  header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                        "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg,
                                         "invoice_number" => $invoice_number,
                                        "order_number"=>$model->order_number
                                        
                                    ));
                             }else if($_REQUEST['payment_mode'] == "on_credit"){
                                 $msg = "Validaion Error: Check your file fields for correctness";
                                 header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                        "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg,
                                         "invoice_number" => $invoice_number,
                                        "order_number"=>$model->order_number
                                        
                                    ));
                             }
                                
                            
                        }else{
                            $msg = "We shall contact you to complete this transaction offline as there is an issue with the order placement. However, the order number is '$model->order_number' and the invoice number is '$invoice_number'. Please keep this numbers for this transaction reference";
                                 header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                        "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg,
                                        
                                    ));
                            
                        }
                           
                   
                  
            
                    
                }else{
                    $msg = 'Attempt to place this order was not successful. Please try again or contact customer service';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                               );
                
                
                }
                       
                   }else{
                        $msg = 'Your status as a Prime Member could not be verified. Please try and complete this transaction as a non prime member';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                               );
                       
                   }
                    
                    
                    
                    
                }else{
                    $msg = 'Is possible you have already placed this order as this cart is closed.';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                               );
                    
                }
                
                
            
            
            
        }
        
        /**
         * This is the function that retrieves all the items in a cart
         */
        public function getAllTheItemsInThisCart($cart_id){
            $model = new CartItem;
            return $model->getAllTheItemsInThisCart($cart_id);
        }
        
        
        /**
         * This is the function that retrieves the cost per unit of an item in a cart
         */
        public function getTheCostPerItemOfThisItem($item){
            $model = new CartItem;
            return $model->getTheCostPerItemOfThisItem($item);
        }
        
        
        /**
         * This is the function that retrieves the unit of an item in a cart
         */
        public function getTheUnitOfThisItem($item){
            $model = new CartItem;
            return $model->getTheUnitOfThisItem($item);
        }
        
        
        /**
         * This is the function that retrieves the unit of an item in a cart
         */
        public function getThePrimeCustomerDiscountRateOfThisItem($item){
            $model = new CartItem;
            return $model->getThePrimeCustomerDiscountRateOfThisItem($item);
        }
        
        
        
        /**
         * This is the function that retrieves the quantity of an item in a cart
         */
        public function getThisCartItemQuantity($item){
            $model = new CartItem;
            return $model->getTheQuantityOfThisCartItem($item);
        }
        
        
        /**
         * This is the function that retrieves the measurement type id of a cart item
         */
        public function getTheMeasurementTypeOfThisCartItem($item){
            $model = new CartItem;
            return $model->getTheMeasurementTypeOfThisCartItem($item);
        }
        
        
        /**
         * This is the function that retrieves the promotional id of an item in a cart
         */
        public function getThePromotionIdOfThisCartItemId($item){
            $model = new CartItem;
            return $model->getThePromotionIdOfThisCartItemId($item);
        }
        
        /*8
         * This is the function that retrieves the pricing id of an item in a cart
         */
        public function getThePricingIdOfThisCartItem($item){
            $model = new CartItem;
            return $model->getThePricingIdOfThisCartItem($item);
        }
        
        
        /**
         * This is the function that retrieves the email address of a logged im user
         */
        public function getTheEmailAddressOfThisUser($user_id){
            $model = new User;
            return $model->getTheEmailAddressOfThisUser($user_id);
        }
        
        /**
         * This is the function that closes a cart
         */
        public function closeThisCart($cart_id){
            $model = new Cart;
            return $model->closeThisCart($cart_id);
        }
        
        /**
         * This is the function that confirms if a cart is open
         */
        public function isThisCartOpen($cart_id){
            $model = new Cart;
            return $model->isThisCartOpen($cart_id);
        }
        
        
        /**
         * This is the function that retrieves the product id of a cart item
         */
        public function getTheProductIdOfThisItem($item){
            $model = new CartItem;
            return $model->getTheProductIdOfThisItem($item);
        }
        
        
        /**
         * This is the function that list customer all orders
         */
        public function actionlistCustomerAllOrders(){
            $user_id = $_REQUEST['user_id'];
            
            $status = $_REQUEST['status'];
            
            if($status == 'all'){
                $data = [];
            
                $q = "select a.order_number, a.status,a.delivery_address,a.delivery_city_id,a.receiver_mobile_number,a.address_landmark,a.nearest_bus_stop,a.is_a_prime_member,a.receiver_mobile_number,
                    a.person_in_care_of,a.delivery_preference,a.other_relevent_information,a.date_ordered, b.order_id,b.quantity,b.promotion_type, c.id as product_id,c.icon,c.name,b.id as id,
                    b.cost_per_unit,b.prime_customer_discount_rate,b.unit,b.id as order_item_id,b.has_user_confirmed_receipt,
                    (select symbol from measurement_type where id=b.quantity_measurement_type_id) as unit,
                    (select name from contractor where id=b.courier_id) as courier,
                    (select name from contractor where id=b.packager_id) as packager,
                    (select price_per_unit from pricing where id=b.pricing_id) as price,
                    (select prime_customer_discount_rate from pricing where id=b.pricing_id) as prime_customer_discount_rate,
                    (select name from merchant where id=c.merchant_id) as merchant,
                    (select name from city where id=a.delivery_city_id) as delivery_city from `order` a 
                    JOIN order_item b ON a.id=b.order_id
                    JOIN product c ON b.product_id=c.id
                     where a.ordered_by=$user_id
                    group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "order"=>$data,
                                    
                                   
                    
                            ));
                
                
            }else if($status == 'open'){
                
                $data = [];
            
                $q = "select a.order_number, a.status,a.delivery_address,a.delivery_city_id,a.receiver_mobile_number,a.address_landmark,a.nearest_bus_stop,a.is_a_prime_member,a.receiver_mobile_number,
                    a.person_in_care_of,a.delivery_preference,a.other_relevent_information,a.date_ordered, b.order_id,b.quantity,b.promotion_type,c.id as product_id,c.icon,c.name,b.id as id,
                    b.cost_per_unit,b.prime_customer_discount_rate,b.unit, b.id as order_item_id,b.has_user_confirmed_receipt,
                    (select symbol from measurement_type where id=b.quantity_measurement_type_id) as unit,
                    (select name from contractor where id=b.courier_id) as courier,
                    (select name from contractor where id=b.packager_id) as packager,
                    (select price_per_unit from pricing where id=b.pricing_id) as price,
                    (select prime_customer_discount_rate from pricing where id=b.pricing_id) as prime_customer_discount_rate,
                    (select name from merchant where id=c.merchant_id) as merchant,
                    (select name from city where id=a.delivery_city_id) as delivery_city from `order` a 
                    JOIN order_item b ON a.id=b.order_id
                    JOIN product c ON b.product_id=c.id
                     where a.ordered_by=$user_id and a.status='open'
                    group by  b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "order"=>$data,
                                    
                                   
                    
                            ));
                
                
            }else if($status == 'closed'){
                
                $data = [];
            
                $q = "select a.order_number, a.status,a.delivery_address,a.delivery_city_id,a.receiver_mobile_number,a.address_landmark,a.nearest_bus_stop,a.is_a_prime_member,a.receiver_mobile_number,
                    a.person_in_care_of,a.delivery_preference,a.other_relevent_information,a.date_ordered, b.order_id,b.quantity,b.promotion_type,c.id as product_id,c.icon,c.name,b.id as id,
                    b.cost_per_unit,b.prime_customer_discount_rate,b.unit,b.id as order_item_id,b.has_user_confirmed_receipt,
                    (select symbol from measurement_type where id=b.quantity_measurement_type_id) as unit,
                    (select name from contractor where id=b.courier_id) as courier,
                    (select name from contractor where id=b.packager_id) as packager,
                    (select price_per_unit from pricing where id=b.pricing_id) as price,
                    (select prime_customer_discount_rate from pricing where id=b.pricing_id) as prime_customer_discount_rate,
                    (select name from merchant where id=c.merchant_id) as merchant,
                    (select name from city where id=a.delivery_city_id) as delivery_city from `order` a 
                    JOIN order_item b ON a.id=b.order_id
                    JOIN product c ON b.product_id=c.id
                     where a.ordered_by=$user_id and a.status='closed'
                    group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "order"=>$data,
                                    
                                   
                    
                            ));
                
                
                
            }
            
            
            
        }
        
        
        /**
         * This is the function that places an order for anonynous buy now customer 
         */
        public function actionplaceorderbymobile(){
            $model = new Order;
            
                $delivery_cost = $_REQUEST['delivery_cost'];
                $total_cost_deposit = $_REQUEST['total_cost_deposit'];
                $model->status = "open";
                $model->delivery_address = $_REQUEST['delivery_address'];
                $model->delivery_city_id = $_REQUEST['delivery_city_id'];
                $model->receiver_mobile_number = $_REQUEST['receiver_mobile_number'];
                $model->address_landmark = $_REQUEST['address_landmark'];
                $model->nearest_bus_stop = $_REQUEST['nearest_bus_stop'];
                $model->person_in_care_of = $_REQUEST['person_in_care_of'];
                $model->delivery_preference = strtolower($_REQUEST['delivery_preference']);
                $model->other_relevent_information = $_REQUEST['other_relevent_information'];
                $model->date_ordered = new CDbExpression('NOW()');
                $model->ordered_by = $_REQUEST['logged_in_user_id'];
                $model->email = $_REQUEST['email'];
                $model->mobile_number = $_REQUEST['mobile_number'];
                $cart_id=0;
                $bank_details = $_REQUEST['bank_details'];
                        
                
                $model->order_number = $model->generateThisOrderUniqueNumber($cart_id,$_REQUEST['warehouse_location_id'],$model->delivery_city_id);
                $error_counter = 0;
                
                
                
                   if($_REQUEST['is_a_prime_member']==1){
                       if($this->isThisUserAPrimeMember($_REQUEST['prime_member_number'])){
                           $model->is_a_prime_member = $_REQUEST['is_a_prime_member'];
                            $model->prime_member_number = $_REQUEST['prime_member_number'];
                            $total_price_of_items= $_REQUEST['prime_members_total_price_post_promotion_and_delivery'];
                            $is_a_prime_member=1;
                       }else{
                           $error_counter = $error_counter + 1;
                           $is_a_prime_member=0;
                           $total_price_of_items= $_REQUEST['total_price_post_promotion_and_delivery'];
                           $model->prime_member_number ="";
                       }
                       
                   }else{
                        $model->is_a_prime_member = 0;
                        $model->prime_member_number = " ";
                        $total_price_of_items= $_REQUEST['total_price_post_promotion_and_delivery'];
                        $is_a_prime_member=0;
                   }
                   
                 if($_REQUEST['payment_mode'] == "on_deposit_using_online"){
                       $total_cost_deposit = round($total_cost_deposit,2);
                       $total_price_of_items = round($total_price_of_items,2);
                       
                   }else if($_REQUEST['payment_mode'] == "on_deposit_using_bank_transfer"){
                       $total_cost_deposit = round($total_cost_deposit,2);
                       $total_price_of_items = round($total_price_of_items,2);
                   }else{
                       $total_cost_deposit=round($total_price_of_items,2);
                       $total_price_of_items=round($total_price_of_items,2);
                   }
                
                
                   
                   if($error_counter == 0){
                       if($model->save()){
                          $cost_per_unit = $this->getThePriceOfThisPricingId($_REQUEST['pricing_id']);
                          $unit = $this->getTheUnitOfThisPricing($_REQUEST['pricing_id']);
                          $prime_customer_discount_rate = $this->getThePrimeCustomerDiscountRate($_REQUEST['pricing_id']);
                    if($this->isOrderItemDetailsCorrectlyCreated($model->id,$_REQUEST['product_id'],$_REQUEST['quantity'],$_REQUEST['measurement_type_id'],$_REQUEST['promotion_id'],$_REQUEST['pricing_id'],$model->ordered_by,$cost_per_unit,$unit,$prime_customer_discount_rate)){
                        $invoice_number = $this->makePaymentAndGenerateTheInvoiceNumber($model->id,$model->order_number,$_REQUEST['payment_mode'],$delivery_cost,$total_cost_deposit,$total_price_of_items,$model->ordered_by,$cart_id,$_REQUEST['warehouse_location_id'],$model->delivery_city_id);
                             if($_REQUEST['payment_mode'] == "on_deposit_using_online"){
                                  header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                        "success" => mysqli_connect_errno() == 0,
                                        "invoice_number" => $invoice_number,
                                        "order_number"=>$model->order_number,
                                        "is_a_prime_member"=>$is_a_prime_member,
                                        "amount"=>round($total_cost_deposit,2),
                                        "email"=>$model->email,
                                        "membership_number"=>$model->prime_member_number
                                    ));
                                 
                             }else if($_REQUEST['payment_mode'] == "on_deposit_using_bank_transfer"){
                                 $msg = "Your order number is '$model->order_number' and the invoice number is '$invoice_number'. Please effect transfer using the order number attribute for easy verification";
                                 header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                        "success" => mysqli_connect_errno() == 0,
                                        "msg" =>$msg,
                                         "invoice_number" => $invoice_number,
                                        "order_number"=>$model->order_number,
                                        "is_a_prime_member"=>$is_a_prime_member
                                    ));
                                 
                             }else if($_REQUEST['payment_mode'] == "online"){
                                 header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                        "success" => mysqli_connect_errno() == 0,
                                        "invoice_number" => $invoice_number,
                                        "order_number"=>$model->order_number,
                                        "is_a_prime_member"=>$is_a_prime_member=0,
                                        "amount"=>round($total_price_of_items,2),
                                        "email"=>$model->email,
                                        "membership_number"=>$model->prime_member_number
                                    ));
                                 
                             }else if($_REQUEST['payment_mode'] == "on_delivery"){
                                 $msg = "Your order number is '$model->order_number' and the invoice number is '$invoice_number'. On delivery you will have to pay the total sum of '=N=$total_price_of_items' before taking ownership of the product ";
                                 header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                        "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg,
                                        "invoice_number" => $invoice_number,
                                        "order_number"=>$model->order_number,
                                        "is_a_prime_member"=>$is_a_prime_member=0,
                                        "amount"=>round($total_price_of_items,2),
                                        "email"=>$model->email,
                                        "membership_number"=>$model->prime_member_number
                                        
                                    ));
                                 
                             }else if($_REQUEST['payment_mode'] == "bank_transfer"){
                                 $msg = "Effect the bank transfer using this order number: '$model->order_number' in the transfer instruction. However, the invoice number of this transaction is '$invoice_number'";
                                  header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                        "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg,
                                         "invoice_number" => $invoice_number,
                                        "order_number"=>$model->order_number,
                                        "is_a_prime_member"=>$is_a_prime_member=0,
                                        "amount"=>round($total_price_of_items,2),
                                        "email"=>$model->email,
                                        "membership_number"=>$model->prime_member_number,
                                        "bank_details"=>$bank_details
                                        
                                    ));
                             }else if($_REQUEST['payment_mode'] == "on_credit"){
                                 $msg = "Validaion Error: Check your file fields for correctness";
                                 header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                        "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg,
                                         "invoice_number" => $invoice_number,
                                        "order_number"=>$model->order_number
                                        
                                    ));
                             }
                                
                   
                    }
                }else{
                    $msg = 'Attempt to place this order was not successful. Please try again or contact customer service';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                               );
                
                
                }
                       
                   }else{
                        $msg = 'Your Prime Membership number could not be verified. Kindly check the number and try again';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                               );
                       
                   }
            
            
                
          
            
            
        }
}
