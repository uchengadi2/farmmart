<?php

class InventoryController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listAllInventoriesInThisWarehouse','addproducttowarehouse','removeproductfromwarehouse',
                                    'updateproductquantityinwarehouse','listAllMerchantInventories'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that list all inventories in a warehouse
         */
        public function actionlistAllInventoriesInThisWarehouse(){
            
            $model = new Inventory;
           
            
            $warehouse_id = $_REQUEST['warehouse_id'];
            
             $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='warehouse_id=:wareid';
              $criteria->params = array(':wareid'=>$warehouse_id);
              $inventory= Inventory::model()->findAll($criteria);
              if($inventory===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                         header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "inventory" => $inventory,
                                  
                    
                            ));
                       
                       
                }
        }
        
        
        /**
         * This is the function that adds a product to a warehouse
         */
        public function actionaddproducttowarehouse(){
            
            $model = new Inventory;
            
            $model->product_id = $_REQUEST['product_id'];
            $model->warehouse_id = $_REQUEST['warehouse_id'];
            $model->quantity = $_REQUEST['quantity'];
            $model->quantity_measurement_type_id = $_REQUEST['measurement_type_id'];
            $warehouse_name = $_REQUEST['warehouse_name'];            
            if($model->isThisProductAlreadyAssignedToThisWarehouse($model->product_id,$model->warehouse_id)==false){
                if($model->save()){
                $msg = "This new product is successfully added to the '$warehouse_name' warehouse";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
            }else{
                $msg = "Attempt to add this product to the '$warehouse_name' warehouse was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
            }
                
                
            }else{
                $msg = 'This product is already in this warehouse. You can only update its quantity or remove it entirely from the warehouse';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                
            }
                    
        }
        
        
        /**
         * This is the function that removes a product from a warehouse
         */
        public function actionremoveproductfromwarehouse(){
            
            $model = new Inventory;
            
            $model->product_id = $_REQUEST['product_id'];
            $model->warehouse_id = $_REQUEST['warehouse_id'];
            $warehouse_name = $_REQUEST['warehouse_name'];       
                        
           if($model->isThisProductAlreadyAssignedToThisWarehouse($model->product_id,$model->warehouse_id)){
                if($model->isTheRemovalOfThisProductFromThisWarehouseASuccess($model->product_id,$model->warehouse_id)){
                    $msg = "The product is successfully removed from the '$warehouse_name' warehouse";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                }else{
                    $msg = "Attempt to remove this product from the '$warehouse_name' warehouse was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                }
           }else{
                $msg = 'This product is not in this warehouse and therefore the request is ignored';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
           }
            
            
        }
        
        
        /**
         * This is the function that updates the quantity of a product in  a warehouse
         */
        public function actionupdateproductquantityinwarehouse(){
            
            //get the inventory id of this inventory
            $inventory_id = $this->getTheInventoryIdOfThisInventory($_REQUEST['product_id'],$_REQUEST['warehouse_id']);
            $model=  Inventory::model()->findByPk($inventory_id);
            $model->quantity = $_REQUEST['quantity'];
            $model->quantity_measurement_type_id = $_REQUEST['measurement_type_id'];
            $warehouse_name = $_REQUEST['warehouse_name'];     
            
            if($model->isThisProductAlreadyAssignedToThisWarehouse($model->product_id,$model->warehouse_id)){
                
                if($model->save()){
                $msg = "The update of this product quantity in the '$warehouse_name' warehouse is successfully ";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
            }else{
                $msg = "Attempt to add update the quantity of this product in the '$warehouse_name' warehouse was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
            }
                
            }else{
                 $msg = 'This product is not in this warehouse and therefore the request is ignored';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                
            }
        }
        
        /**
         * This is the function that retrieves an inventory id 
         */
        public function getTheInventoryIdOfThisInventory($product_id,$warehouse_id){
            $model = new Inventory;
            return $model->getTheInventoryIdOfThisInventory($product_id,$warehouse_id);
        }
        
        
        /**
         * This is the product that list all merchant inventories
         */
        public function actionlistAllMerchantInventories(){
           
            $model = new User;
            
            $user_id = Yii::app()->user->id;
            
            $merchant_id = $model->getTheMerchantIdOfThisUser($user_id);
            
            //list all the inventries in the marketplace
            $inventories = Inventory::model()->findAll();
            
            $target = [];
            //confirm if an inventory belongs to a merchant
            foreach($inventories as $inventory){
                if($this->isThisInventoryForThisMerchant($inventory['warehouse_id'],$merchant_id)){
                    $target[] = $inventory;
                }
                   
            }
            
            if($inventories===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                        header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "inventory" => $target,
                                   
                    
                            ));
                       
                }
        }
        
        
        /**
         * This is the function that confirms if an inventory belongs to a merchant
         */
        public function isThisInventoryForThisMerchant($warehouse_id,$merchant_id){
            $model = new Warehouse;
            return $model->isThisInventoryForThisMerchant($warehouse_id,$merchant_id);
        }
}
