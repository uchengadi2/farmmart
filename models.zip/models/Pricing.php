<?php

/**
 * This is the model class for table "pricing".
 *
 * The followings are the available columns in table 'pricing':
 * @property string $id
 * @property string $inventory_id
 * @property double $price_per_unit
 * @property integer $measurement_type_id
 * @property string $create_time
 * @property string $update_time
 * @property integer $create_user_id
 * @property integer $update_user_id
 */
class Pricing extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'pricing';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('inventory_id, measurement_type_id', 'required'),
			array('measurement_type_id, create_user_id, update_user_id', 'numerical', 'integerOnly'=>true),
			array('price_per_unit', 'numerical'),
			array('inventory_id', 'length', 'max'=>10),
			array('create_time, update_time', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, inventory_id, price_per_unit, measurement_type_id, create_time, update_time, create_user_id, update_user_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'inventory_id' => 'Inventory',
			'price_per_unit' => 'Price Per Unit',
			'measurement_type_id' => 'Measurement Type',
			'create_time' => 'Create Time',
			'update_time' => 'Update Time',
			'create_user_id' => 'Create User',
			'update_user_id' => 'Update User',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('inventory_id',$this->inventory_id,true);
		$criteria->compare('price_per_unit',$this->price_per_unit);
		$criteria->compare('measurement_type_id',$this->_measurement_type_id);
		$criteria->compare('create_time',$this->create_time,true);
		$criteria->compare('update_time',$this->update_time,true);
		$criteria->compare('create_user_id',$this->create_user_id);
		$criteria->compare('update_user_id',$this->update_user_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return Pricing the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        /**
         * This is the function that confirms if a price per unit is existing in a warehoue
         */
        public function isThisPriceAlreadyAssignedToThisProduct($measurement_type_id,$inventory_id){
            
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('pricing')
                    ->where("inventory_id = $inventory_id and measurement_type_id=$measurement_type_id");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
         /**
         * This is the function that retrieves the pricing id of a product in a warehouse
         */
        public function getThePricingIdOfThisProductInTheWarehouse($product_id, $warehouse_id,$measurement_type_id){
            $model = new Inventory;
            //get the required inventory id
            $inventory_id = $model->getTheInventoryIdOfThisInventory($product_id, $warehouse_id);
            
             $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='inventory_id=:invid and measurement_type_id=:typeid';
              $criteria->params = array(':invid'=>$inventory_id,':typeid'=>$measurement_type_id);
              $pricing= Pricing::model()->find($criteria);
              
              return $pricing['id'];
        }
        
        
        
         /**
         * This is the function that confirms if a the removal of price per unit of a product in a warehouse is a success
         */
        public function isTheRemovalOfThisPricePerUnitFromThisProductInTheWarehouseASuccess($model){
            
            if($this->isThisPromotionRemovalASuccess($model->id)){
               if($model->delete()){
                   return true;
               }else{
                   return false;
               }
                
            }else{
                return false;
                
            }
           
            
             
        }
        
        /**
         * This is the function that confirms if the deleteion of a promotion is successful
         */
        public function isThisPromotionRemovalASuccess($pricing_id){
            $model = new Promotion;
            return $model->isThisPromotionRemovalASuccess($pricing_id);
        }
        
        
        
        /**
         * This is the function that confirms if a product already had a default price
         */
        public function isThisProductAlreadyWithDefaultPrice($product_id){
            
            $model = new Inventory;
            
            $counter = 0;
            
            //get all the inventory associated with this product
            $inventories = $model->getAllTheInventoryIdsAssociatedWithProducts($product_id);
            
            foreach($inventories as $inv){
                if($this->isThisInventoryWithDefaultPrice($inv)){
                    $counter = $counter + 1;
                }
            }
            if($counter>0){
                return true;
            }else{
                return false;
            }
        }
        
       /**
        * This is the function that confirms if inventory is with a default price
        */
        public function isThisInventoryWithDefaultPrice($inventory_id){
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('pricing')
                    ->where("inventory_id = $inventory_id and is_default_price=1");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
         /**
         * this is the function that gets the default pricing id of an inventory
         */
    public function getTheDefaultPricingIdOfThisProductInTheWarehouse($product_id, $warehouse_id){
        $model = new Inventory;
            //get the required inventory id
            $inventory_id = $model->getTheInventoryIdOfThisInventory($product_id, $warehouse_id);
            
             $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='inventory_id=:invid and is_default_price=1';
              $criteria->params = array(':invid'=>$inventory_id);
              $pricing= Pricing::model()->find($criteria);
              
              return $pricing['id'];
    }
    
    
    /**
     * This is the function that confirms if the default pricing of a product is on promotion
     */
    public function isThisProductDefaultPricingOnPromotion($product_id){
        $q = "select  count(*) from product a 
                    JOIN inventory b ON a.id=b.product_id
                    JOIN pricing c ON b.id=c.inventory_id
                    where a.id=$product_id and c.is_default_price =1 and c.is_pricing_on_promotion=1";
                    
        $cmd = Yii::app()->db->createCommand($q);
         $result = $cmd->queryScalar();
         
         if($result>0){
             return true;
         }else{
             return false;
         }
             

    }
    
    
    
    /**
     * This is the function that confirms if the this pricing of a product is on promotion
     */
    public function isThisProductPricingOnPromotion($product_id,$warehouse_location_id,$unit_type_id){
        $q = "select  count(*) from product a 
                    JOIN inventory b ON a.id=b.product_id
                    JOIN pricing c ON b.id=c.inventory_id
                    where a.id=$product_id and c.id =(select id from pricing where measurement_type_id= $unit_type_id and inventory_id=(select id from inventory where product_id=$product_id and warehouse_id=(select id from warehouse where city_id=$warehouse_location_id)))";
                    
        $cmd = Yii::app()->db->createCommand($q);
         $result = $cmd->queryScalar();
         
         if($result>0){
             return true;
         }else{
             return false;
         }
             

    }
    
    /**
     * This is the function that confirms if pricing information is accurate
     */
    public function isThisPricingAuthentic($pricing_id,$prime_customer_discount_rate,$measurement_type_id,$price,$is_pricing_on_promotion){
        
         $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('pricing')
                    ->where("id =$pricing_id and (prime_customer_discount_rate=$prime_customer_discount_rate and measurement_type_id=$measurement_type_id) and (price_per_unit=$price and is_pricing_on_promotion=$is_pricing_on_promotion)");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
    }
    
    
    /**
     * This is the function that confirms a promotion is for a pricing
     */
    public function isThisPromotionForThisPricing($pricing_id,$promotion_id,$is_pricing_on_promotion,$promotion_type){
        if($is_pricing_on_promotion == 1){
             $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('promotion')
                    ->where("id =$promotion_id and pricing_id=$pricing_id");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
            
        }else{
            return true;
        }
    }
    
    
    /**
     * This is the function that confirms if a pricing is linked to a product
     */
    public function isPricingForThisProduct($product_id,$pricing_id,$warehouse_location_id){
        $q = "select count(*) from pricing a
                    JOIN inventory b ON a.inventory_id=b.id
                    where a.id=$pricing_id and a.inventory_id = (select id from inventory where product_id=$product_id and warehouse_id =(select id from warehouse where city_id=$warehouse_location_id))";
                    
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->queryScalar();
             
             if($result>0){
                    return true;
                }else{
                    return false;
                }
             
    }
    
    
    /**
     * This is the function that retrieves the measurement type of a pricing
     */
    public function getTheMeasurementTypeOfThisPricing($pricing_id){
        $criteria = new CDbCriteria();
        $criteria->select = '*';
        $criteria->condition='id=:id';
        $criteria->params = array(':id'=>$pricing_id);
        $pricing= Pricing::model()->find($criteria);
        
        return $pricing['measurement_type_id'];
    }
    
    
    /**
     * This is the function that gets the warehouse location id of a pricing
     */
    public function getTheWarehouseLocationIdOfThisPricing($pricing_id){
        $model = new Inventory;
        $criteria = new CDbCriteria();
        $criteria->select = '*';
        $criteria->condition='id=:id';
        $criteria->params = array(':id'=>$pricing_id);
        $pricing= Pricing::model()->find($criteria);
        
        $warehouse_id = $model->getTheWarehouseForThisPricing($pricing['inventory_id']);
        return $this->getTheCityWhereThisWarehouseIsLocated($warehouse_id);
    }
    
    
    /**
     * This is the function that retrieves the city were a warehouse is located
     */
    public function getTheCityWhereThisWarehouseIsLocated($warehouse_id){
        $model = new Warehouse;
        return $model->getTheCityWhereThisWarehouseIsLocated($warehouse_id);
    }
    
    
    /**
     * This is the function that retrieves the price per unit of a pricing i
     */
    public function getThePriceOfThisPricingId($pricing_id){
        
        $criteria = new CDbCriteria();
        $criteria->select = '*';
        $criteria->condition='id=:id';
        $criteria->params = array(':id'=>$pricing_id);
        $pricing= Pricing::model()->find($criteria);
        
        return $pricing['price_per_unit'];
        
        
    }    
    
    
    
     /**
     * This is the function that retrieves the prime member discount rate of a pricing id
     */
    public function getThePrimeCustomerDiscountRate($pricing_id){
        
        $criteria = new CDbCriteria();
        $criteria->select = '*';
        $criteria->condition='id=:id';
        $criteria->params = array(':id'=>$pricing_id);
        $pricing= Pricing::model()->find($criteria);
        
        return $pricing['prime_customer_discount_rate'];
        
        
    }  
    
    
    /**
     * This is the function that retrieves the unit of a pricing id
     */
    public function getTheUnitOfThisPricing($pricing_id){
        $model = new MeasurementType;
        $criteria = new CDbCriteria();
        $criteria->select = '*';
        $criteria->condition='id=:id';
        $criteria->params = array(':id'=>$pricing_id);
        $pricing= Pricing::model()->find($criteria);
        
        $unit = $model->getTheSymbolOfThisMeasurementType($pricing['measurement_type_id']);
        
        return $unit;
        
        
    }    
}
