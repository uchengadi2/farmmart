<?php

/**
 * This is the model class for table "associated_promotion".
 *
 * The followings are the available columns in table 'associated_promotion':
 * @property string $id
 * @property string $promotion_id
 * @property string $other_product_pricing_id
 * @property double $other_product_pricing_discount_rate
 * @property double $minimum_applicable_quantity
 * @property string $update_time
 * @property string $create_time
 * @property integer $create_user_id
 * @property integer $update_user_id
 * @property string $type
 */
class AssociatedPromotion extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'associated_promotion';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('promotion_id, type', 'required'),
			array('create_user_id, update_user_id', 'numerical', 'integerOnly'=>true),
			array('other_product_pricing_discount_rate, minimum_applicable_quantity', 'numerical'),
			array('promotion_id, other_product_pricing_id', 'length', 'max'=>10),
			array('type', 'length', 'max'=>9),
			array('update_time, create_time', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, promotion_id, other_product_pricing_id, other_product_pricing_discount_rate, minimum_applicable_quantity, update_time, create_time, create_user_id, update_user_id, type', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'promotion_id' => 'Promotion',
			'other_product_pricing_id' => 'Other Product Pricing',
			'other_product_pricing_discount_rate' => 'Other Product Pricing Discount Rate',
			'minimum_applicable_quantity' => 'Minimum Applicable Quantity',
			'update_time' => 'Update Time',
			'create_time' => 'Create Time',
			'create_user_id' => 'Create User',
			'update_user_id' => 'Update User',
			'type' => 'Type',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('promotion_id',$this->promotion_id,true);
		$criteria->compare('other_product_pricing_id',$this->other_product_pricing_id,true);
		$criteria->compare('other_product_pricing_discount_rate',$this->other_product_pricing_discount_rate);
		$criteria->compare('minimum_applicable_quantity',$this->minimum_applicable_quantity);
		$criteria->compare('update_time',$this->update_time,true);
		$criteria->compare('create_time',$this->create_time,true);
		$criteria->compare('create_user_id',$this->create_user_id);
		$criteria->compare('update_user_id',$this->update_user_id);
		$criteria->compare('type',$this->type,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return AssociatedPromotion the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
         /**
         * this is the function that sets the deafult associate promotion for a promotion
         */
        public function registerTheDefaultAssociatePromotion($promotion_id){
            $model = new AssociatedPromotion;
            
            if($this->isPromotionAlreadyWithassociatePromotion($promotion_id)){
                return 0;
            }else{
                $model->type = "none";
                $model->promotion_id = $promotion_id;
                
                if($model->save()){
                    return $model->id;
                }else{
                    return -1;
                }
            }
            
        }
        
        
        
        /**
         * This is the function that confirms if a promotion already has an associate promotion
         */
        public function isPromotionAlreadyWithassociatePromotion($promotion_id){
             $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('associated_promotion')
                    ->where("promotion_id = $promotion_id");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        /**
         * This is the function that confirms if the associate promotions of a promotion  is removed successfully
         */
        public function isTheAssociatePromotionsRemovalASuccess($promotion_id){
            $cmd =Yii::app()->db->createCommand();  
                $result = $cmd->delete('associated_promotion', 'promotion_id=:promoid', array(':promoid'=>$promotion_id));
            
                if($result>0){
                    return true;
                    
                    
                }else{
                    return false;
                }
                
               
            }
            
            
            /**
         * This is the function that registers a dummy assciate promotion
         */
        public function regiserDummyAssociatePromotionForThisPromotion($promotion_id){
            $model = new AssociatedPromotion;
            
            $model->promotion_id = $promotion_id;
            $model->type = "none";
            
            if($model->save()){
                return true;
            }else{
                return false;
            }
        }
        
        
        /**
         * This is the function that confirms if an associate promotion is deletable
         */
        public function isThisAssociatePromotionDeletable($model){
            $number_of_associates = $this->getTheNumberOfAssociatePromotion($model->promotion_id);
            if($number_of_associates >1){
                return true;
            }else{
                if($this->isAssociatePromotionType($model->id) == "none"){
                    return false;
                }else{
                    //recreate a dummy associate promotion
                    $this->registerDummyAssociatePromotionForThisPromtion($model->promotion_id);
                    return true;
                }
            }
        }
        
        
        
        /**
         * this is the fuction that gets the  number of associate promotions
         */
        public function getTheNumberOfAssociatePromotion($promotion_id){
             $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('associated_promotion')
                    ->where("promotion_id = $promotion_id");
                $result = $cmd->queryScalar();
                
                return $result;
        }
        
        
        /**
         * This is the function that retrieves the associate promotion type
         */
        public function isAssociatePromotionType($id){
             $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='id=:id';
              $criteria->params = array(':id'=>$id);
              $associate= AssociatedPromotion::model()->find($criteria);
              
              return $associate['type'];
        }
        
        
        
         /**
         * This is the function that registers a dummy associate promotion for a promotion 
         */
        public function registerDummyAssociatePromotionForThisPromtion($promotion_id){
            $model = new AssociatedPromotion;
            
            $model->promotion_id = $promotion_id;
            $model->type ="none";
            
            if($model->save()){
                return true;
            }else{
                return false;
            }
        }
}
