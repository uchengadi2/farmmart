<?php

/**
 * This is the model class for table "promotion".
 *
 * The followings are the available columns in table 'promotion':
 * @property string $id
 * @property string $pricing_id
 * @property string $type
 * @property string $condition
 * @property integer $x_quantity
 * @property integer $y_quantity
 * @property string $y_product
 * @property string $y_product_quantity
 * @property double $y_percentage
 * @property string $start_date
 * @property string $end_date
 * @property string $create_time
 * @property string $update_time
 * @property integer $create_user_id
 * @property integer $update_user_id
 */
class Promotion extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'promotion';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('pricing_id, type', 'required'),
			array('x_quantity, y_quantity, create_user_id, update_user_id', 'numerical', 'integerOnly'=>true),
			array('y_percentage', 'numerical'),
			array('pricing_id', 'length', 'max'=>10),
			array('type', 'length', 'max'=>29),
			array('condition, y_product, y_product_quantity', 'length', 'max'=>250),
			array('start_date, end_date, create_time, update_time', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, pricing_id, type, condition, x_quantity, y_quantity, y_product, y_product_quantity, y_percentage, start_date, end_date, create_time, update_time, create_user_id, update_user_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'pricing_id' => 'Pricing',
			'type' => 'Type',
			'condition' => 'Condition',
			'x_quantity' => 'X Quantity',
			'y_quantity' => 'Y Quantity',
			'y_product' => 'Y Product',
			'y_product_quantity' => 'Y Product Quantity',
			'y_percentage' => 'Y Percentage',
			'start_date' => 'Start Date',
			'end_date' => 'End Date',
			'create_time' => 'Create Time',
			'update_time' => 'Update Time',
			'create_user_id' => 'Create User',
			'update_user_id' => 'Update User',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('pricing_id',$this->pricing_id,true);
		$criteria->compare('type',$this->type,true);
		$criteria->compare('condition',$this->condition,true);
		$criteria->compare('x_quantity',$this->x_quantity);
		$criteria->compare('y_quantity',$this->y_quantity);
		$criteria->compare('y_product',$this->y_product,true);
		$criteria->compare('y_product_quantity',$this->y_product_quantity,true);
		$criteria->compare('y_percentage',$this->y_percentage);
		$criteria->compare('start_date',$this->start_date,true);
		$criteria->compare('end_date',$this->end_date,true);
		$criteria->compare('create_time',$this->create_time,true);
		$criteria->compare('update_time',$this->update_time,true);
		$criteria->compare('create_user_id',$this->create_user_id);
		$criteria->compare('update_user_id',$this->update_user_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return Promotion the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        /**
         * This is the function that confirms if a price already has a promotion on it
         */
        public function isThisPriceAlreadyWithAPromotion($price_id){
            
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('promotion')
                    ->where("pricing_id = $price_id");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        
        /**
         * This is the function that gets a promotion id of a pricing
         */
        public function getThePromotionIdOfThisPricing($price_id){
            $model = new Promotion;
           $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='pricing_id=:priceid';
              $criteria->params = array(':priceid'=>$price_id);
              $promotion= Promotion::model()->find($criteria);
              return $promotion['id'];
        }    
        
        
        /**
         * This is the function that registers a pricing promotion
         */
        public function registerPricingForPromotion($pricing_id){
            $model = new Promotion;
            
            $model->pricing_id = $pricing_id;
            $model->type = "none";
            
            if($model->save()){
                //register  dummy associate promotion
                $this->registerDummyAssociatePromotionForThisPromtion($model->id);
                return true;
            }else{
                return false;
            }
        }
        
        
        /**
         * This is the function that registers associate promotion for a promotion
         */
        public function registerDummyAssociatePromotionForThisPromtion($promotion_id){
            $model = new AssociatedPromotion;
            return $model->registerDummyAssociatePromotionForThisPromtion($promotion_id);
        }
        
        
        /**
         * This is the function that deletes a pricing promotion
         */
        public function isThisPromotionRemovalASuccess($pricing_id){
           
            $model = new AssociatedPromotion;
            $promotion_id = $this->getThePromotionIdOfThisPricing($pricing_id);
            
            if($model->isTheAssociatePromotionsRemovalASuccess($promotion_id)){
                $cmd =Yii::app()->db->createCommand();  
                $result = $cmd->delete('promotion', 'pricing_id=:pricingid', array(':pricingid'=>$pricing_id));
            
                if($result>0){
                    return true;
                    
                }else{
                    return false;
                }
            }else{
                return false;
            }
            
        }
       
        
        /**
         * This is the function that confirms if  associate promotions of a promtion is deleted successfully
         */
        public function isTheAssociatePromotionsRemovalASuccess($promotion_id){
            $model = new AssociatedPromotion;
            return $model->isTheAssociatePromotionsRemovalASuccess($promotion_id);
        }
}
