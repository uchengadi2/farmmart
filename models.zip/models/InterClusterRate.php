<?php

/**
 * This is the model class for table "inter_cluster_rate".
 *
 * The followings are the available columns in table 'inter_cluster_rate':
 * @property string $id
 * @property string $first_cluster_id
 * @property string $second_cluster_id
 * @property double $inter_cluster_base_rate
 * @property double $inter_cluster_maximum_base_weight
 * @property double $inter_cluster_per_additional_kg
 * @property string $create_time
 * @property integer $create_user_id
 * @property string $update_time
 * @property integer $update_user_id
 */
class InterClusterRate extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'inter_cluster_rate';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('first_cluster_id, second_cluster_id', 'required'),
			array('create_user_id, update_user_id', 'numerical', 'integerOnly'=>true),
			array('inter_cluster_base_rate, inter_cluster_maximum_base_weight, inter_cluster_per_additional_kg', 'numerical'),
			array('first_cluster_id, second_cluster_id', 'length', 'max'=>10),
			array('create_time, update_time', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, first_cluster_id, second_cluster_id, inter_cluster_base_rate, inter_cluster_maximum_base_weight, inter_cluster_per_additional_kg, create_time, create_user_id, update_time, update_user_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'first_cluster_id' => 'First Cluster',
			'second_cluster_id' => 'Second Cluster',
			'inter_cluster_base_rate' => 'Inter Cluster Base Rate',
			'inter_cluster_maximum_base_weight' => 'Inter Cluster Maximum Base Weight',
			'inter_cluster_per_additional_kg' => 'Inter Cluster Per Additional Kg',
			'create_time' => 'Create Time',
			'create_user_id' => 'Create User',
			'update_time' => 'Update Time',
			'update_user_id' => 'Update User',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('first_cluster_id',$this->first_cluster_id,true);
		$criteria->compare('second_cluster_id',$this->second_cluster_id,true);
		$criteria->compare('inter_cluster_base_rate',$this->inter_cluster_base_rate);
		$criteria->compare('inter_cluster_maximum_base_weight',$this->inter_cluster_maximum_base_weight);
		$criteria->compare('inter_cluster_per_additional_kg',$this->inter_cluster_per_additional_kg);
		$criteria->compare('create_time',$this->create_time,true);
		$criteria->compare('create_user_id',$this->create_user_id);
		$criteria->compare('update_time',$this->update_time,true);
		$criteria->compare('update_user_id',$this->update_user_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return InterClusterRate the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        /**
         * This is the function that determines if an inter cluster rate had already been set
         */
        public function isThisInterClusterRateAlreadySet($first_cluster_id,$second_cluster_id,$preference){
            
             $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('inter_cluster_rate')
                    ->where("first_cluster_id = $first_cluster_id and second_cluster_id=$second_cluster_id and preference='$preference'");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        /**
         * This is the function that retrieves an intercluster rate id
         */
        public function getThisInterClusterId($first_cluster_id,$second_cluster_id){
            $model = new NeighbourhoodCities;
            $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='first_cluster_id=:firstid and second_cluster_id=:secondid';
              $criteria->params = array(':firstid'=>$first_cluster_id,':secondid'=>$second_cluster_id);
              $intercluster= InterClusterRate::model()->find($criteria);
              
              return $intercluster['id'];
        }
        
        
        /**
         * This is the function that gets the standard inter cluster rate between two cit clusters
         */
        public function getTheInterClusterRateOfTheseCities($delivery_city_id,$store_location_id,$total_weight_for_delivery,$delivery_preference){
            $model = new ClusterNeighbourhoods;
            
            $delivery_city_cluster = $model->getTheClusterIdOfThisCityNeighbourhood($delivery_city_id);
            
            $store_city_cluster = $model->getTheClusterIdOfThisCityNeighbourhood($store_location_id);
            
              $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='(first_cluster_id=:firstid and second_cluster_id=:secondid) and preference=:preference';
              $criteria->params = array(':firstid'=>$store_city_cluster,':secondid'=>$delivery_city_cluster,':preference'=>"$delivery_preference");
              $intercluster= InterClusterRate::model()->find($criteria);
              
              if($intercluster['inter_cluster_maximum_base_weight']>=$total_weight_for_delivery){
                      return $intercluster['inter_cluster_base_rate'];
                  }else{
                       $weight_diff = (double)$total_weight_for_delivery - (double)$intercluster['inter_cluster_maximum_base_weight'];
                       $rate = $intercluster['inter_cluster_base_rate'] + ($weight_diff * (double)$intercluster['inter_cluster_per_additional_kg']);
                       return $rate;
                  }
            
        }
}
