# ext-theme-neptune-056eac78-8f5b-401d-913e-12f3124f40cd/resources

This folder contains static resources (typically an `"images"` folder as well).
